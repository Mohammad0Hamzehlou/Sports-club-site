import { useState } from 'react';
import './styles.css';

function App() {
  const [isInfoVisible, setIsInfoVisible] = useState(false);

  const toggleInfo = () => {
    setIsInfoVisible(!isInfoVisible);
  };

  return (
    <div
      style={{
        margin: 0,
        padding: 0,
        fontFamily: "'Noto Sans JP', 'vazir', sans-serif",
        backgroundColor: '#000',
        backgroundImage: "url('/image.png')",
        backgroundRepeat: 'no-repeat',
        backgroundPosition: 'center center',
        backgroundSize: '50%',
        color: '#f3d304',
        position: 'relative',
        minHeight: '100vh',
      }}
    >
      {/* لایه تیره پس‌زمینه */}
      <div
        style={{
          content: '""',
          position: 'absolute',
          top: 0,
          left: 0,
          width: '100%',
          height: '100%',
          backgroundColor: 'rgba(0, 0, 0, 0.6)',
          zIndex: 1,
        }}
      />

      {/* هدر */}
      <header
        style={{
          position: 'relative',
          zIndex: 2,
          padding: '20px',
          textAlign: 'center',
          fontSize: '1.5rem',
          backgroundColor: 'rgba(0, 0, 0, 0.8)',
          borderBottom: '2px solid #ffcc00',
        }}
      >
        <h1 style={{ margin: 0, fontSize: '2.5rem', color: '#ffcc00' }}>
          باشگاه نینجوتسو
        </h1>
        <nav
          style={{
            display: 'flex',
            justifyContent: 'center',
            gap: '20px',
            marginTop: '10px',
          }}
        >
          <a
            href="/"
            style={{
              textDecoration: 'none',
              color: '#ffcc00',
              fontSize: '1.2rem',
              padding: '10px 15px',
              border: '1px solid #ffcc00',
              borderRadius: '5px',
              transition: 'background-color 0.3s',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#ffcc00';
              e.currentTarget.style.color = '#e0e0e0';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = '#ffcc00';
            }}
          >
            صفحه اصلی
          </a>
          <a
            href="/about"
            style={{
              textDecoration: 'none',
              color: '#ffcc00',
              fontSize: '1.2rem',
              padding: '10px 15px',
              border: '1px solid #ffcc00',
              borderRadius: '5px',
              transition: 'background-color 0.3s',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#ffcc00';
              e.currentTarget.style.color = '#e0e0e0';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = '#ffcc00';
            }}
          >
            درباره ما
          </a>
          <a
            href="/classes"
            style={{
              textDecoration: 'none',
              color: '#ffcc00',
              fontSize: '1.2rem',
              padding: '10px 15px',
              border: '1px solid #ffcc00',
              borderRadius: '5px',
              transition: 'background-color 0.3s',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#ffcc00';
              e.currentTarget.style.color = '#e0e0e0';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = '#ffcc00';
            }}
          >
            کلاس‌ها
          </a>
          <a
            href="#!"
            style={{
              textDecoration: 'none',
              color: '#ffcc00',
              fontSize: '1.2rem',
              padding: '10px 15px',
              border: '1px solid #ffcc00',
              borderRadius: '5px',
              transition: 'background-color 0.3s',
            }}
            onMouseOver={(e) => {
              e.currentTarget.style.backgroundColor = '#ffcc00';
              e.currentTarget.style.color = '#e0e0e0';
            }}
            onMouseOut={(e) => {
              e.currentTarget.style.backgroundColor = 'transparent';
              e.currentTarget.style.color = '#ffcc00';
            }}
          >
            تصاویر
          </a>
        </nav>
      </header>

      {/* بخش هیرو */}
      <section
        className="hero"
        style={{
          position: 'relative',
          zIndex: 2,
          textAlign: 'center',
          padding: '100px 20px',
          margin: '20px',
          borderRadius: '15px',
        }}
      >
        <h2 style={{ fontSize: '2.2rem', marginBottom: '20px', color: '#ffcc00' }}>
          هنر کهن نینجوتسو
        </h2>
        <p
          style={{
            fontSize: '1.2rem',
            lineHeight: '1.8',
            color: '#ffcc00',
          }}
        >
          باشگاه نینجوتسو با هدف آموزش هنر رزمی نینجاها در فضایی الهام‌گرفته از
          فرهنگ ژاپن و اژدهای افسانه‌ای ژاپنی، شما را به سفری به گذشته می‌برد.
          اینجا مکانی برای یادگیری مهارت‌های رزمی، تقویت ذهن و بدن، و تجربه معنای
          واقعی هماهنگی است.
        </p>
        <a
          href="/register"
          style={{
            display: 'inline-block',
            marginTop: '20px',
            padding: '10px 20px',
            fontSize: '1.2rem',
            color: '#000',
            backgroundColor: '#ffcc00',
            textDecoration: 'none',
            borderRadius: '5px',
            transition: 'background-color 0.3s',
          }}
          onMouseOver={(e) => (e.currentTarget.style.backgroundColor = '#b39554')}
          onMouseOut={(e) => (e.currentTarget.style.backgroundColor = '#ffcc00')}
        >
          ثبت‌نام در کلاس‌ها
        </a>
      </section>

      {/* فوتدر */}
      <footer
        style={{
          position: 'relative',
          zIndex: 2,
          textAlign: 'center',
          padding: '10px',
          borderTop: '2px solid #ffcc00',
          fontSize: '0.9rem',
          marginTop: '20px',
        }}
      >
        <p style={{ margin: 0 }}>
          © 2025 باشگاه نینجوتسو | تمامی حقوق محفوظ است.
        </p>
        <p
          style={{
            fontSize: '2rem',
            color: '#ffcc00',
            marginTop: '20px',
          }}
        >
          اژدهای ژاپنی در کنار شماست!
        </p>

        {/* بخش تماس */}
        <section style={{ marginTop: '20px' }}>
          <div style={{ display: 'inline-block' }}>
            <div
              style={{
                cursor: 'pointer',
                fontSize: '2rem',
                color: '#ffcc00',
              }}
              onClick={toggleInfo}
            >
              <i className="fab fa-telegram"></i>
            </div>
            {isInfoVisible && (
              <div
                style={{
                  marginTop: '10px',
                  color: '#ffcc00',
                }}
              >
                <span>تلگرام: 09109780152</span> &nbsp;&nbsp;
                <span>واتس‌اپ: 09109780152</span> &nbsp;&nbsp;
                <span>تلفن: 09109780152</span>
              </div>
            )}
          </div>
        </section>
      </footer>
    </div>
  );
}

export default App;